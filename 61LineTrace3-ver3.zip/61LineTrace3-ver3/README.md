#61LineTrace3 PID制御を利用したライントレース

TouchSensorで止まる
BASE_SPEEDを導入

＋＋＋
白の輝度、黒の輝度を計測してから、中間を求めてスタート